package com.sirenhead.entity;

import com.sirenhead.data.SirenVariants;
import com.sirenhead.data.StepShake;
import com.sirenhead.registry.ModBlocks;
import com.sirenhead.registry.ModEntities;
import com.sirenhead.registry.ModSounds;
import com.sirenhead.util.Fx;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.monster.AbstractIllager;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.ExperienceOrb;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * One class for all 36 "ho:*" Siren Head variants of the Bedrock addon. Port of the behavior-pack state machine:
 * component groups (bd:melee_con, attack1..6, sonic_blast, pickup, picked, stunned, ...), property bd:melee,
 * the animation-timeline command lists of animations/siren_call.json and the stun / dead controllers.
 */
public class SirenHeadEntity extends Monster implements GeoEntity {
    // ---- synced "properties" (bd:melee, bd:move_arou, bd:killed) + is_stunned
    private static final EntityDataAccessor<Integer> MELEE = SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> MOVE_AROUND = SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> KILLED = SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> STUNNED = SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.BOOLEAN);

    public final SirenVariants.V variant;
    /** MAX_HEALTH attribute is capped at 1024 by vanilla; real variant health (up to 100000) is emulated by scaling incoming damage. */
    private final float healthScale;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private enum Phase { CON, CHOOSE_DIST, CHOOSE_RANGED, CON2, ATTACK, MOVE_AWAY, PICK_CON, PICKUP, PICKED, STUNNED, DEAD }
    private Phase phase = Phase.CON;
    private int phaseTicks, lastInside = -1, fastTimer;
    private int attackCode, attackLen, attackTick;
    private final List<Timed> timeline = new ArrayList<>();
    private boolean naturalSpawn, locked;
    private int lifeTicks, stunStage, alertCooldown, stepCooldown, lastSeen;
    private int deadTicks;
    private static final float[] STUN_AT = {0.9f, 0.8f, 0.75f, 0.5f, 0.35f, 0.1f};
    private record Timed(int tick, Runnable run) {}

    public SirenHeadEntity(EntityType<? extends SirenHeadEntity> type, Level level, SirenVariants.V v) {
        super(type, level);
        this.variant = v;
        float cap = Math.min(1024.0F, v.health);
        this.healthScale = cap / v.health;
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(cap);
        this.setMaxUpStep(8.0F);
        this.noCulling = true;
        this.xpReward = 0;
        this.setHealth(this.getMaxHealth());
        resetFast();
    }

    public static AttributeSupplier.Builder attributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 1024.0)               // overwritten per variant in the constructor
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FOLLOW_RANGE, 200.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.ATTACK_DAMAGE, 0.0);
    }

    // ------------------------------------------------------------------ data / health
    @Override protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(MELEE, 0);
        entityData.define(MOVE_AROUND, 0);
        entityData.define(KILLED, false);
        entityData.define(STUNNED, false);
    }
    public int getMelee() { return entityData.get(MELEE); }
    public int getMoveAround() { return entityData.get(MOVE_AROUND); }
    public boolean isKilled() { return entityData.get(KILLED); }
    public boolean isStunned() { return entityData.get(STUNNED); }

    @Override public void setHealth(float h) { super.setHealth(Mth.clamp(h, 1.0F, getMaxHealth())); }   // minecraft:health min 1
    @Override public boolean causeFallDamage(float a, float b, DamageSource s) { return false; }           // damage_sensor: fall
    @Override public boolean fireImmune() { return true; }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public void checkDespawn() {}
    @Override public boolean isPushable() { return phase != Phase.DEAD && super.isPushable(); }
    @Override public boolean canBeLeashed(Player p) { return false; }

    /** controller siren_stun_damage: while stunned every health loss is followed by `damage @s 30 override`. */
    @Override protected void actuallyHurt(DamageSource src, float amount) {
        if (isStunned() && amount > 0) amount += 30f;
        super.actuallyHurt(src, amount * healthScale);
    }
    @Override public boolean hurt(DamageSource src, float amount) {
        boolean r = super.hurt(src, amount);
        if (r && !level().isClientSide && src.getEntity() instanceof LivingEntity a && !(a instanceof SirenHeadEntity) && getTarget() == null) setTarget(a);
        return r;
    }

    @Nullable @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor l, DifficultyInstance d, MobSpawnType reason, @Nullable SpawnGroupData g, @Nullable CompoundTag t) {
        naturalSpawn = reason == MobSpawnType.NATURAL || reason == MobSpawnType.CHUNK_GENERATION || reason == MobSpawnType.REINFORCEMENT;
        return super.finalizeSpawn(l, d, reason, g, t);
    }

    @Override public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putBoolean("Natural", naturalSpawn); t.putInt("Life", lifeTicks); t.putInt("StunStage", stunStage);
        t.putBoolean("Killed", isKilled()); t.putInt("DeadTicks", deadTicks);
    }
    @Override public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        naturalSpawn = t.getBoolean("Natural"); lifeTicks = t.getInt("Life"); stunStage = t.getInt("StunStage");
        deadTicks = t.getInt("DeadTicks");
        if (t.getBoolean("Killed")) { entityData.set(KILLED, true); phase = Phase.DEAD; }
    }

    // ------------------------------------------------------------------ helpers
    private int ticks(double sec) { return (int) Math.round(sec * 20.0); }
    private Vec3 L(double l, double u, double f) { return Fx.local(this, l, u, f); }
    private void at(double sec, Runnable r) { timeline.add(new Timed(ticks(sec), r)); }
    private void setMelee(int v) { entityData.set(MELEE, v); }
    private void resetFast() { fastTimer = ticks(8 + random.nextDouble() * 7); }
    private void slam(String n, Vec3 p) {
        var o = ModEntities.SLAMS.get(n);
        if (o == null) return;
        Entity e = o.get().create(level());
        if (e != null) { e.moveTo(p.x, p.y, p.z, getYRot(), 0); level().addFreshEntity(e); }
    }
    private void part(String id, Vec3 p) { Fx.particle(level(), id, p.add(0, 0.1, 0)); }
    private void stopMove() { getNavigation().stop(); }
    private double dist(LivingEntity t) { return Math.sqrt(distanceToSqr(t)); }

    private void faceTarget(float maxTurn) {
        LivingEntity t = getTarget();
        if (t == null) return;
        double dx = t.getX() - getX(), dz = t.getZ() - getZ();
        float want = (float) (Mth.atan2(dz, dx) * (180F / Math.PI)) - 90.0F;
        float yaw = Mth.approachDegrees(getYRot(), want, maxTurn);
        setYRot(yaw); setYHeadRot(yaw); setYBodyRot(yaw);
        double dy = (t.getEyeY()) - getEyeY();
        double h = Math.sqrt(dx * dx + dz * dz);
        setXRot(Mth.clamp((float) -(Mth.atan2(dy, h) * (180F / Math.PI)), -45, 45));
    }

    private void chase(LivingEntity t, double mult) {
        if (t == null) return;
        faceTarget(30f);
        getMoveControl().setWantedPosition(t.getX(), t.getY(), t.getZ(), mult);
    }

    private static int weighted(RandomSource r, double... w) {
        double sum = 0; for (double x : w) sum += x;
        double p = r.nextDouble() * sum;
        for (int i = 0; i < w.length; i++) { p -= w[i]; if (p <= 0) return i; }
        return w.length - 1;
    }

    // ------------------------------------------------------------------ phases / events
    private void enter(Phase p) { phase = p; phaseTicks = 0; lastInside = -1; locked = false; attackCode = 0; setMelee(0); setMoveAroundVal(0); timeline.clear(); }
    private void setMoveAroundVal(int v) { entityData.set(MOVE_AROUND, v); }
    private void enterCon() { removeEffect(MobEffects.MOVEMENT_SLOWDOWN); enter(Phase.CON); }   // event bd:melee_con

    /** event bd:melee_choose_dist */
    private void meleeChooseDist() { if (weighted(random, 5, 5.1) == 0) enter(Phase.CHOOSE_DIST); else enter(Phase.CHOOSE_RANGED); }

    /** event bd:choose_attack  (target inside 8 from bd:melee_con) */
    private void chooseAttack() {
        switch (weighted(random, 4, 6, 5, 5, 6, 6, 2.5, 3, 4, 8)) {
            case 0 -> startAttack(1); case 1 -> startAttack(2); case 2 -> startAttack(3); case 3 -> startAttack(5);
            case 4 -> startAttack(6); case 5 -> startAttack(7); case 6 -> enter(Phase.PICK_CON);
            case 7 -> startMoveAway(1); case 8 -> startMoveAway(2); default -> startAttack(8);
        }
    }
    /** event bd:choose_attack2 */
    private void chooseAttack2() {
        switch (weighted(random, 4, 4, 6, 5, 4, 6, 3)) {
            case 0 -> startAttack(1); case 1 -> startAttack(2); case 2 -> startAttack(3); case 3 -> startAttack(5);
            case 4 -> startAttack(6); case 5 -> startAttack(7); default -> enter(Phase.PICK_CON);
        }
    }
    /** event bd:choose_ranged */
    private void chooseRanged() {
        switch (weighted(random, 4, 3, 4.5, 3, 1.4)) {
            case 0 -> startAttack(9); case 1 -> startMoveAway(1); case 2 -> startAttack(11);
            case 3 -> startMoveAway(2); default -> startAttack(10);
        }
    }
    /** event bd:melee_fast (timer 8-15s): far target -> bd:melee_choose_ranged group */
    private void meleeFast() {
        LivingEntity t = getTarget();
        if (t != null && dist(t) >= 15.0) enter(Phase.CHOOSE_RANGED);
    }
    private void startMoveAway(int side) { enter(Phase.MOVE_AWAY); setMoveAroundVal(side); phaseTicks = 0; attackLen = ticks(2 + random.nextDouble()); }

    // ------------------------------------------------------------------ attacks (animations/siren_call.json timelines)
    private void startAttack(int code) {
        enter(Phase.ATTACK);
        attackCode = code; attackTick = 0; setMelee(code);
        faceTarget(360f); stopMove();
        switch (code) {
            case 1 -> { attackLen = ticks(3.25); locked = true;
                at(1.0, () -> Fx.damageArea(this, L(0, 0, 9.5), 10, false, 0f, "none"));
                at(1.14, () -> { Vec3 p = L(0, 0, 6.5); part("wind_up", p); Fx.impulseArea(this, p, 7, false, 0, 2.5, -4); slam("slam_up", p); slam("slam_up", p.add(0, 6, 0)); }); }
            case 2 -> { attackLen = ticks(3.0); locked = true;
                at(0.75, () -> Fx.impulse(this, 0, 0, 1.3));
                at(0.8, () -> Fx.damageArea(this, L(0, 0, 9.5), 10, false, 0f, "none"));
                at(0.93, () -> { Vec3 p = L(0, 0, 9.5); Fx.shake(level(), p, 30, 1f, 0.4f); slam("slam", p); slam("slam", p); });
                at(1.03, () -> Fx.impulseArea(this, L(0, 0, 9.5), 10, false, 0, 1, -4)); }
            case 3 -> { attackLen = ticks(3.75); locked = true;
                at(1.0, () -> { Fx.impulse(this, 0, 0, 1.3); slam("slam_down", L(0, 0, 3)); Fx.shake(level(), position(), 30, 1f, 0.3f); });
                at(1.1, () -> { Vec3 p = L(0, 0, 3); part("ground_damage", p); part("siren_range2", p); part("earth_claw2", p); }); }
            case 5 -> { attackLen = ticks(6); locked = true;      // attack4
                at(1.0, () -> Fx.damageArea(this, L(-4, 0, 5), 10, false, 0f, "none"));
                at(1.08, () -> { Vec3 p = L(-4, 0, 5); Fx.shake(level(), p, 30, 1f, 0.4f);
                    for (String s : new String[]{"earth_claw2", "siren_range2", "siren_dust2", "ground_damage", "siren_dust_up", "siren_dust_strike"}) part(s, p);
                    slam("slam_good", p); });
                at(1.18, () -> Fx.impulseArea(this, L(-4, 0, 5), 10, false, 0, 1.5, -2));
                at(2.7, () -> { Vec3 p = L(-4, 0, 5); Fx.shake(level(), p, 50, 2f, 0.5f); part("siren_dust_strike", p); part("earth_claw2", p);
                    part("siren_range", L(0, 0, 3)); part("siren_dust_up", p); slam("slam_down2", p); });
                at(2.85, () -> Fx.impulseArea(this, L(-4, 0, 5), 10, false, 0, 2.0, -5)); }
            case 6 -> { attackLen = ticks(3.0); locked = true;    // attack5
                at(0.75, () -> Fx.impulse(this, 0, 0, 1.3));
                at(0.8, () -> Fx.damageArea(this, L(0, 0, 9.5), 10, false, 0f, "none"));
                at(0.93, () -> { Vec3 p = L(0, 0, 9.5); Fx.shake(level(), p, 30, 1f, 0.4f); slam("slam", p); });
                at(1.1, () -> Fx.impulseArea(this, L(0, 0, 9.5), 10, false, 0, 1, -4)); }
            case 11 -> { attackLen = ticks(6);                    // attack6: chases at 2.0x until 2.1s
                at(2.1, () -> { Fx.damageArea(this, L(0, 0, 5), 10, false, 0f, "none"); locked = true; });
                at(2.2167, () -> { Vec3 p = L(0, 0, 5); Fx.shake(level(), p, 30, 1f, 0.4f);
                    for (String s : new String[]{"siren_dust_strike", "siren_range2", "siren_range", "earth_claw2", "siren_dust_up"}) part(s, p);
                    slam("slam_down2", p); });
                at(2.3, () -> Fx.impulseArea(this, L(0, 0, 5), 10, false, 0, 1, -4)); }
            case 7 -> { attackLen = ticks(5);                     // attack1_combo (melee speed 0.1)
                at(3.0, () -> locked = true);
                at(0.75, () -> Fx.impulse(this, 0, 0, 2.0));
                at(1.0, () -> Fx.damageArea(this, L(0, 0, 9.5), 10, false, 0f, "none"));
                at(0.93, () -> { Vec3 p = L(0, 0, 9.5); Fx.shake(level(), p, 30, 1f, 0.4f); slam("slam", p); slam("slam", p); });
                at(1.1, () -> Fx.impulseArea(this, L(0, 0, 9.5), 10, false, 0, 1, -3));
                at(2.25, () -> Fx.impulse(this, 0, 0, 3.5));
                at(2.63, () -> { Vec3 p = L(0, 0, 9.5); Fx.shake(level(), p, 30, 1f, 0.4f); slam("slam", p); slam("slam", p); });
                at(2.73, () -> Fx.impulseArea(this, L(0, 0, 9.5), 10, false, 0, 1, -3)); }
            case 8 -> { attackLen = ticks(2.5);                   // jump_avoid
                at(0.5, () -> { Fx.impulse(this, 0, 0.5, -4); Fx.damageArea(this, position(), 10, true, 2f, "entity_attack"); });
                at(1.19, () -> { part("ground_damage", position()); Fx.damageArea(this, position(), 10, true, 7f, "entity_attack"); }); }
            case 9 -> { attackLen = ticks(3.1);                   // jump_ford
                at(0.55, () -> Fx.impulse(this, 0, 0.6, 2));
                at(1.1, () -> { Fx.shake(level(), position(), 30, 1.2f, 0.3f); Vec3 p = L(0, 0, 9.5);
                    part("ground_damage", p); slam("slam_down", p); part("siren_dust_up", p); part("earth_claw2", p); part("siren_range", p); });
                at(1.3, () -> Fx.impulse(this, 0, 0.0, 1.5));
                at(1.4, () -> Fx.damageArea(this, L(0, 0, 9.5), 8, true, 35f, "entity_explosion"));
                at(1.55, () -> Fx.impulseArea(this, L(0, 0, 9.5), 8, true, 0, 2, -5)); }
            case 10 -> { attackLen = ticks(12); spawnTar();       // sonic_blast: 4s wind-up, wave, 12s total
                at(1.3, () -> { Fx.shake(level(), L(0, 0, 5), 30, 1f, 1.2f);   // function sirenhead/shot_melee
                    slam("slam_down", L(4, 0, 5)); slam("slam_down", L(-4, 0, 5));
                    part("ground_damage", L(0, 0, 5)); part("siren_dust_up", L(0, 0, 5));
                    part("siren_range2", L(4, 0, 5)); part("siren_range2", L(-4, 0, 5));
                    part("earth_claw2", L(4, 0, 5)); part("earth_claw2", L(-4, 0, 5)); });
                at(1.4, () -> Fx.impulseArea(this, L(0, 0, 3.5), 10, false, 0, 2, -4));
                at(4.0, this::fireWave); }
            default -> {}
        }
    }

    /** function sirenhead/sonic_blast/spawn_tar */
    private void spawnTar() {
        Vec3 p = switch (random.nextInt(3)) { case 1 -> L(30, 1, 20); case 2 -> L(-30, 1, 20); default -> position(); };
        Entity e = ModEntities.SIREN_TAR.get().create(level());
        if (e != null) { e.moveTo(p.x, p.y, p.z, getYRot(), 0); level().addFreshEntity(e); }
    }
    /** group siren_shot: minecraft:spawn_entity of the variant's wave projectile */
    private void fireWave() {
        var w = com.sirenhead.data.WaveTypes.ALL.stream().filter(x -> x.name().equals(variant.wave)).findFirst().orElse(null);
        var t = ModEntities.WAVES.get(variant.wave);
        if (w != null && t != null) WaveEntity.shoot(this, w, t.get());
    }

    // ------------------------------------------------------------------ pick up / grab
    private static boolean grabbable(Entity e) {
        return e instanceof Player p ? !p.isCreative() && !p.isSpectator() : (e instanceof AbstractIllager || e instanceof IronGolem);
    }
    /** function sirenhead/bat_choi */
    private void batChoi() {
        Vec3 p10 = L(0, 0, 10);
        Player pl = level().getNearestPlayer(p10.x, p10.y, p10.z, 10, e -> grabbable(e));
        LivingEntity v = pl;
        if (v == null) {
            double best = 100;
            for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(10), x -> x != this && !(x instanceof Player) && grabbable(x))) {
                double d = e.distanceToSqr(this); if (d < best) { best = d; v = e; }
            }
        } else { v.teleportTo(p10.x, p10.y, p10.z); }
        if (v != null && getPassengers().isEmpty()) v.startRiding(this, true);
    }
    @Override protected boolean canAddPassenger(Entity e) { return getPassengers().isEmpty() && (phase == Phase.PICKUP || phase == Phase.PICKED); }
    @Override public void positionRider(Entity p, MoveFunction cb) {
        Vec3 s = L(0.1, 0.2, 0.4);     // minecraft:rideable seat [-0.1, 0.2, 0.4]
        cb.accept(p, s.x, s.y, s.z);
    }
    private void startPicked() {
        phase = Phase.PICKED; phaseTicks = 0; timeline.clear(); attackTick = 0; setMelee(4); locked = true;
        addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 140, 5, false, false));          // bat_choi2: effect resistance 7 5
        at(1.75, () -> pickHit(25f, L(-5, 0, 4), 4));
        at(2.3, () -> pickHit(35f, L(-5, 0, 4), 4));
        at(3.88, () -> { pickHit(105f, L(-5, 0, 6), 6); part("siren_dust_up", L(-5, 0, 6)); part("ground_damage", L(-5, 0, 6)); Fx.shake(level(), position(), 70, 1.5f, 1.0f); });
        at(5.7, this::evict);
        at(5.8, () -> { for (Entity e : level().getEntities(this, getBoundingBox().inflate(10))) if (e instanceof Player p && !p.isCreative()) { Vec3 d = L(-5, 0, 6); if (p.distanceToSqr(this) < 100) p.teleportTo(d.x, d.y, d.z); } });
    }
    private void pickHit(float dmg, Vec3 second, double r) {
        Fx.damageArea(this, position(), 5, true, dmg, "entity_attack");
        Fx.damageArea(this, second, 5, true, dmg, "entity_attack");
        part("siren_range2", second); part("earth_claw2", second);
        Fx.shake(level(), position(), 35, 1f, 0.5f);
    }
    private void evict() { ejectPassengers(); }

    // ------------------------------------------------------------------ stun / death
    private void stunDetect() {
        if (isStunned() || stunStage >= STUN_AT.length || phase == Phase.DEAD) return;
        if (getHealth() <= getMaxHealth() * STUN_AT[stunStage]) {
            stunStage++;
            if (weighted(random, 30, 50) == 0) {            // event bd:stunned (weight 30 vs nothing 50)
                ejectPassengers();
                enter(Phase.STUNNED);
                entityData.set(STUNNED, true);
                addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 3, false, false));
            }
        }
    }
    private void enterDead() {
        ejectPassengers();
        enter(Phase.DEAD);
        entityData.set(KILLED, true); entityData.set(STUNNED, false);
        removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        deadTicks = 0;
    }

    // ------------------------------------------------------------------ targeting
    private boolean validTarget(Entity e) {
        if (e == this || !(e instanceof LivingEntity l) || !l.isAlive()) return false;
        if (e instanceof Player p) return !p.isCreative() && !p.isSpectator();
        if (variant.targetsSirens && e instanceof SirenHeadEntity) return true;
        return e instanceof SnowGolem || e instanceof IronGolem || e instanceof AbstractIllager || e instanceof Ravager
                || e instanceof Villager || e instanceof WanderingTrader;
    }
    private void retarget() {
        // family siren_tar has priority 0: always preferred, no line of sight needed
        SirenTarEntity tar = null; double best = 200 * 200;
        for (SirenTarEntity t : level().getEntitiesOfClass(SirenTarEntity.class, getBoundingBox().inflate(200), x -> x.isTarget)) {
            double d = t.distanceToSqr(this); if (d < best) { best = d; tar = t; }
        }
        if (tar != null) { setTarget(tar); return; }
        LivingEntity cur = getTarget();
        if (cur instanceof SirenTarEntity) cur = null;
        if (cur != null && validTarget(cur) && distanceToSqr(cur) < 200 * 200) {
            if (hasLineOfSight(cur)) lastSeen = lifeTicks;
            else if (naturalSpawn && lifeTicks - lastSeen > 600) cur = null;       // must_see_forget_duration 30s
            if (cur != null) { setTarget(cur); return; }
        }
        LivingEntity pick = null; best = 200 * 200;
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(200), this::validTarget)) {
            double d = e.distanceToSqr(this);
            if (d < best && hasLineOfSight(e)) { best = d; pick = e; }
        }
        setTarget(pick);
        if (pick != null) lastSeen = lifeTicks;
    }

    // ------------------------------------------------------------------ tick
    @Override public void tick() {
        super.tick();
        if (!level().isClientSide) serverTick();
    }

    private void serverTick() {
        lifeTicks++;
        if (phase == Phase.DEAD) { deadTick(); return; }
        if (getHealth() <= 1.0F && lifeTicks > 5) { enterDead(); return; }
        if (lifeTicks % 10 == 0) retarget();
        LivingEntity t = getTarget();
        stunDetect();

        // siren.despawn / environment sensor
        if (naturalSpawn) {
            if (lifeTicks >= 6000 && t == null && getMelee() == 0) { discard(); return; }
            if (lifeTicks % 20 == 0 && level().getNearestPlayer(this, 400) == null) { discard(); return; }
        }
        breakLeaves();
        alertSound(t);
        phaseTicks++;

        switch (phase) {
            case CON, CHOOSE_DIST, CHOOSE_RANGED, CON2 -> {
                double mult = switch (phase) { case CON -> 1.4; case CHOOSE_DIST -> 1.6; default -> 2.0; };
                if (t != null) chase(t, mult);
                if (--fastTimer <= 0) { resetFast(); meleeFast(); if (phase != Phase.CON && phase != Phase.CON2 && phase != Phase.CHOOSE_DIST && phase != Phase.CHOOSE_RANGED) break; }
                sensor(t);
                walkFx();
            }
            case MOVE_AWAY -> {
                if (phaseTicks >= attackLen) { removeEffect(MobEffects.MOVEMENT_SLOWDOWN); enter(Phase.CON2); break; }
                // animations siren_move_left/right: scriptevent bd:entity_move (-/+)0.09 0 -0.09 every tick, face target in short windows
                Fx.impulse(this, getMoveAround() == 1 ? -0.09 : 0.09, 0, -0.09);
                int m = phaseTicks % 20;
                if (m < 2 || (m >= 10 && m < 12)) faceTarget(40f);
            }
            case PICK_CON -> { if (phaseTicks >= 1) { phase = Phase.PICKUP; phaseTicks = 0; setMelee(4); attackTick = 0; locked = true; stopMove(); faceTarget(360f); } }
            case PICKUP -> {
                faceTarget(15f);
                if (phaseTicks == 22 || phaseTicks == 23) batChoi();                 // animation siren_picking_time: 1.1s / 1.11s
                if (!getPassengers().isEmpty()) startPicked();
                else if (phaseTicks >= 40) enterCon();                               // pickup timer 2s
            }
            case PICKED -> { attackTick++; runTimeline(); if (getPassengers().isEmpty() && attackTick > 140) enterCon(); if (phaseTicks >= ticks(5.8833)) { evict(); enterCon(); } }
            case STUNNED -> { if (phaseTicks >= 200) { entityData.set(STUNNED, false); enterCon(); } }
            case ATTACK -> attackTick();
            default -> {}
        }
    }

    private void sensor(LivingEntity t) {
        double range = phase == Phase.CHOOSE_RANGED ? 20 : 8;
        if (t == null) { lastInside = -1; return; }
        int cur = dist(t) < range ? 1 : 0;
        if (cur == lastInside) return;
        lastInside = cur;
        boolean inside = cur == 1;
        switch (phase) {
            case CON -> { if (inside) chooseAttack(); else meleeChooseDist(); }
            case CHOOSE_DIST -> { if (inside) chooseAttack2(); else chooseRanged(); }
            case CHOOSE_RANGED -> chooseRanged();
            case CON2 -> { if (inside) chooseAttack2(); }
            default -> {}
        }
    }

    private void attackTick() {
        attackTick++;
        LivingEntity t = getTarget();
        if (attackCode == 11 && attackTick < ticks(2.1) && t != null) chase(t, 2.0);       // group attack6_walk
        else if (attackCode == 7 && t != null && !locked) chase(t, 0.1);                    // attack1_combo melee speed 0.1
        else if (attackCode == 10 && attackTick < ticks(4.0) && t != null) { faceTarget(20f); chase(t, 0.2); }   // ranged_attack
        runTimeline();
        if (attackTick >= attackLen) {
            int code = attackCode;
            removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
            if (code == 8) meleeChooseDist(); else enterCon();
        }
    }
    private void runTimeline() {
        for (Timed e : new ArrayList<>(timeline)) if (e.tick == attackTick) e.run.run();
    }

    private void deadTick() {
        deadTicks++;
        setDeltaMovement(0, getDeltaMovement().y, 0);
        if (deadTicks % 2 == 0 && level() instanceof ServerLevel sl) ExperienceOrb.award(sl, position(), variant.xp);   // bd:dead spawn_entity xp_orb every 0.1s
        if (deadTicks >= 200) {                                                                                            // controller siren_dead -> to_dead
            BlockPos bp = blockPosition();
            level().setBlockAndUpdate(bp, ModBlocks.SIREN_HEAD_HEAD.get().defaultBlockState()
                    .setValue(com.sirenhead.block.SirenHeadHeadBlock.FACING, getDirection().getOpposite()));
            discard();
        }
    }

    /** minecraft:break_blocks [leaves, leaves2] */
    private void breakLeaves() {
        if (tickCount % 4 != 0) return;
        double w = Math.max(2.0, variant.hitW), h = Math.min(variant.hitH, 6.0);
        AABB box = new AABB(getX() - w / 2, getY(), getZ() - w / 2, getX() + w / 2, getY() + h, getZ() + w / 2);
        BlockPos.betweenClosedStream(box).forEach(bp -> {
            BlockState s = level().getBlockState(bp);
            if (s.getBlock() instanceof LeavesBlock) level().destroyBlock(bp, false);
        });
    }

    /** controller siren_alert: idle sound at random 4/10/24/32/43 s intervals while a target exists */
    private void alertSound(LivingEntity t) {
        if (t == null || phase == Phase.DEAD) { alertCooldown = 0; return; }
        if (alertCooldown-- > 0) return;
        alertCooldown = ticks(new int[]{4, 10, 24, 32, 43}[random.nextInt(5)]);
        SoundEvent s = ModSounds.get(variant.sounds[0]);
        if (s != null) level().playSound(null, getX(), getY(), getZ(), s, SoundSource.HOSTILE, 8.0f, 1.0f);
    }

    /** controller siren_walk_fx: footstep sound + distance-ringed camera shake (function move_sound) */
    private void walkFx() {
        Vec3 d = getDeltaMovement();
        double speed = Math.sqrt(d.x * d.x + d.z * d.z);
        if (speed < 0.05 || !onGround()) return;
        if (stepCooldown-- > 0) return;
        stepCooldown = speed * 20 >= 5 ? 6 : 20;
        SoundEvent s = ModSounds.get(variant.sounds[1]);
        if (s != null) level().playSound(null, getX(), getY(), getZ(), s, SoundSource.HOSTILE, 8.0f, 1.0f);
        for (float[] r : StepShake.RINGS) Fx.shakeRing(level(), position(), r[0], r[1], r[2], r[3]);
    }

    // ------------------------------------------------------------------ movement lock (slowness 100 equivalent)
    @Override public void travel(Vec3 v) {
        if (locked || phase == Phase.STUNNED || phase == Phase.DEAD || phase == Phase.PICKUP || phase == Phase.PICKED) {
            super.travel(new Vec3(0, v.y, 0));
            return;
        }
        super.travel(v);
    }
    @Override public boolean isNoAi() { return super.isNoAi(); }

    // ------------------------------------------------------------------ GeckoLib
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        AnimationController<SirenHeadEntity> main = new AnimationController<>(this, "main", 4, this::predicate);
        main.setSoundKeyframeHandler(ev -> {
            SirenHeadEntity e = ev.getAnimatable();
            int i = switch (ev.getKeyframeData().getSound()) { case "idle" -> 0; case "step" -> 1; case "woosh" -> 2; case "slide" -> 3; case "stunned" -> 4; case "hit" -> 5; default -> -1; };
            if (i < 0) return;
            SoundEvent s = ModSounds.get(e.variant.sounds[i]);
            if (s != null) e.level().playLocalSound(e.getX(), e.getY(), e.getZ(), s, SoundSource.HOSTILE, 8.0f, 1.0f, false);
        });
        main.setParticleKeyframeHandler(ev -> {
            SirenHeadEntity e = ev.getAnimatable();
            Fx.clientParticle(e.level(), ev.getKeyframeData().getEffect(), Fx.local(e, 0, 0, 6.0 * e.variant.scale / 2.5));
        });
        c.add(main);
    }

    private PlayState predicate(AnimationState<SirenHeadEntity> st) {
        SirenHeadEntity e = st.getAnimatable();
        String name; boolean hold = false;
        if (e.isKilled()) { name = e.variant.a("dead"); hold = true; }
        else if (e.isStunned()) { name = e.variant.a("stunned"); hold = true; }
        else {
            hold = true;
            name = switch (e.getMelee()) {
                case 1 -> e.variant.a("attack1"); case 2 -> e.variant.a("attack2"); case 3 -> e.variant.a("attack3");
                case 5 -> e.variant.a("attack4"); case 6 -> e.variant.a("attack5"); case 11 -> e.variant.a("attack6");
                case 7 -> e.variant.a("attack1_combo"); case 8 -> e.variant.a("jump_avoid"); case 9 -> e.variant.a("jump_ford");
                case 10 -> e.variant.a("shoot");
                case 4 -> e.variant.a(e.getPassengers().isEmpty() ? "picking" : "picking2");
                default -> { hold = false; yield null; }
            };
            if (name == null) {
                Vec3 d = e.getDeltaMovement();
                double speed = Math.sqrt(d.x * d.x + d.z * d.z) * 20.0;
                if (e.getMoveAround() == 1) name = e.variant.a("moving_l");
                else if (e.getMoveAround() == 2) name = e.variant.a("moving_r");
                else if (speed >= 5) name = e.variant.a("running");
                else if (st.isMoving() || speed > 0.5) name = e.variant.a("moving");
                else name = e.variant.a("general");
            }
        }
        if (name == null) return PlayState.STOP;
        return st.setAndContinue(hold ? RawAnimation.begin().thenPlayAndHold(name) : RawAnimation.begin().thenLoop(name));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
