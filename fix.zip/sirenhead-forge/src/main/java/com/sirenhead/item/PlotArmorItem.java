package com.sirenhead.item;

import com.sirenhead.SirenHeadMod;
import com.sirenhead.client.PlotArmorRenderer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.function.Consumer;
import java.util.function.Supplier;

/** bd:bd_tophat (helmet, 1480 dur) and bd:bd_maid (chestplate, 5480 dur), protection 2000 as in the Bedrock item. */
public class PlotArmorItem extends ArmorItem implements GeoItem {
    public static final class Mat implements ArmorMaterial {
        private final Supplier<Ingredient> repair;
        public Mat(Supplier<Ingredient> repair) { this.repair = repair; }
        public int getDurabilityForType(ArmorItem.Type t) { return switch (t) { case HELMET -> 1480; case CHESTPLATE -> 5480; default -> 0; }; }
        public int getDefenseForType(ArmorItem.Type t) { return 2000; }
        public int getEnchantmentValue() { return 10; }
        public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_LEATHER; }
        public Ingredient getRepairIngredient() { return repair.get(); }
        public String getName() { return SirenHeadMod.MODID + ":plot"; }
        public float getToughness() { return 0; }
        public float getKnockbackResistance() { return 0; }
    }
    public final String geo, texture;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public PlotArmorItem(ArmorMaterial m, ArmorItem.Type t, String geo, String texture) {
        super(m, t, new Properties().stacksTo(1));
        this.geo = geo; this.texture = texture;
    }
    @Override public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private PlotArmorRenderer renderer;
            @Override public HumanoidModel<?> getHumanoidArmorModel(LivingEntity e, ItemStack s, EquipmentSlot slot, HumanoidModel<?> original) {
                if (renderer == null) renderer = new PlotArmorRenderer();
                renderer.prepForRender(e, s, slot, original);
                return renderer;
            }
        });
    }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar c) {}
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
